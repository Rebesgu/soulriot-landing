
# Soul Riot – Landing Page (Vite + React + Tailwind)

This repo contains Alisha's landing page design in React with TailwindCSS, Framer Motion, and Lucide icons.

## Run in GitHub Codespaces (Recommended)
1. Create a new repo and upload this folder, or click **Use this template** if provided.
2. In GitHub, click the green **Code** button → **Open with Codespaces** → **New codespace**.
3. In the terminal:
   ```bash
   npm install
   npm run dev
   ```
4. Open the preview (popup in Codespaces) to see the page.

## Local (optional)
```bash
npm install
npm run dev
```

## Deploy (two easy options)
### Vercel
- Go to vercel.com → **New Project** → Import your GitHub repo → Framework preset: **Vite** → Deploy.

### GitHub Pages
Add this to `package.json`:
```json
"homepage": "https://<your-username>.github.io/<repo-name>/",
```
Then:
```bash
npm run build
# Serve /dist with Pages via actions or gh-pages package
```

## Files to edit
- `src/components/AlishaLandingPage.jsx` – main page contents
- `src/App.jsx` – renders the landing page
- `index.html` – base document
- `src/index.css` – Tailwind entry

