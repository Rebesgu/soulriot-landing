import React from 'react'
import AlishaLandingPage from './components/AlishaLandingPage.jsx'

export default function App() {
  return <AlishaLandingPage />
}
