import React from 'react'
import { motion } from 'framer-motion'
import { Calendar, Zap } from 'lucide-react'

export default function AlishaLandingPage() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      {/* Hero */}
      <section className="relative flex flex-col items-center justify-center text-center py-24 px-6 bg-gradient-to-b from-black via-zinc-900 to-black">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-4xl md:text-6xl font-extrabold text-pink-500 drop-shadow-lg"
        >
          Crystals + Cosmic Tools to Rewrite Your Script
        </motion.h1>
        <p className="mt-6 max-w-2xl text-lg md:text-xl text-gray-300">
          Tactical astrology + crystal strategy for your soul’s evolution. Bold, mystical, and the <span className="text-pink-400 font-bold">real fkn deal</span>.
        </p>
        <a href="#" className="inline-block mt-8 px-8 py-4 rounded-2xl bg-pink-600 hover:bg-pink-700 text-lg font-bold">
          Download Free Tracker
        </a>
      </section>

      {/* Lead Magnet */}
      <section className="py-20 px-6 bg-zinc-950">
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-10 items-center">
          <div className="rounded-2xl border border-pink-500 aspect-[4/3] bg-zinc-800 grid place-items-center text-gray-400">
            tracker-preview.png
          </div>
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-pink-400">
              Free Crystal + Astrology Tracker
            </h2>
            <p className="text-gray-300 mb-6">
              Stop running on the wrong program. Align with cosmic timing, ground your energy with crystals, and rise in your own authority. This tracker is your first step to rewriting the script.
            </p>
            <a href="#" className="inline-block bg-pink-600 hover:bg-pink-700 px-6 py-3 text-lg rounded-2xl">
              Get It Now
            </a>
          </div>
        </div>
      </section>

      {/* Pain Points */}
      <section className="py-20 px-6 bg-gradient-to-r from-pink-600 via-purple-800 to-black text-center">
        <h2 className="text-3xl md:text-5xl font-bold mb-6">Break Cycles. Claim Power.</h2>
        <p className="max-w-3xl mx-auto text-lg text-gray-200">
          Aimlessness and complacency are silent destroyers. Astrology shows the timing. Crystals ground the energy. Together—they’re your tactical edge.
        </p>
      </section>

      {/* Social Proof */}
      <section className="py-20 px-6 bg-black">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-pink-400">
          What They Say
        </h2>
        <div className="max-w-5xl mx-auto grid md:grid-cols-3 gap-8">
          {["The real fkn deal.", "She hypes you AND grounds you.", "Cosmic timing, spot on every time."].map((quote, i) => (
            <div key={i} className="bg-zinc-900 border border-pink-500 rounded-2xl shadow-xl p-6 text-gray-200 italic">
              “{quote}”
            </div>
          ))}
        </div>
      </section>

      {/* Main CTA */}
      <section className="py-24 px-6 bg-zinc-950 text-center">
        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
          Your Year Isn’t Written Yet
        </h2>
        <p className="text-gray-300 max-w-2xl mx-auto mb-8">
          Let’s map it out. Book your <span className="text-pink-400 font-semibold">Planning Your Year with Astrology 2025</span> session today.
        </p>
        <a href="#" className="inline-block px-8 py-4 bg-pink-600 hover:bg-pink-700 text-lg rounded-2xl">
          Book a Reading
        </a>
      </section>

      {/* Events */}
      <section className="py-20 px-6 bg-gradient-to-b from-black via-zinc-900 to-black">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-pink-400 mb-10">
          Catch Me Live
        </h2>
        <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-6">
          <div className="bg-zinc-900 border border-pink-500 rounded-2xl p-6">
            <h3 className="font-bold text-xl mb-2 flex items-center gap-2"><Calendar className="w-5 h-5 text-pink-400"/> Illuminate Festival</h3>
            <p className="text-gray-300">Sept 14, Miami • Astrology Readings + Crystal Grids</p>
          </div>
          <div className="bg-zinc-900 border border-pink-500 rounded-2xl p-6">
            <h3 className="font-bold text-xl mb-2 flex items-center gap-2"><Zap className="w-5 h-5 text-pink-400"/> Ferragamo Fall Collab</h3>
            <p className="text-gray-300">Oct 10, NYC • Crystals + Cosmic Energy Activation</p>
          </div>
        </div>
      </section>

      <footer className="py-10 text-center text-gray-500 text-sm bg-black">
        © {new Date().getFullYear()} Soul Riot LLC. All Rights Reserved.
      </footer>
    </div>
  )
}
